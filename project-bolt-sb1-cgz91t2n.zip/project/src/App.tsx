import React, { useState } from 'react';
import { ThemeToggle } from './components/ThemeToggle';
import { CharacterSearch } from './components/CharacterSearch';
import { CharacterDisplay } from './components/CharacterDisplay';
import { DebugToggle } from './components/DebugToggle';
import { DebugPanel } from './components/debug/DebugPanel';
import { Button } from './components/Button';
import { Rocket, ArrowLeft } from 'lucide-react';
import type { SmartCharacter } from './api/types';

export default function App() {
  const [character, setCharacter] = useState<SmartCharacter | null>(null);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors">
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Rocket className="w-8 h-8 text-blue-500" />
              <div className="flex items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Eve Frontier Tools
                </h1>
                {character && (
                  <Button
                    variant="secondary"
                    onClick={() => setCharacter(null)}
                    className="flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Search
                  </Button>
                )}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <DebugToggle />
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {!character && (
            <CharacterSearch onCharacterFound={setCharacter} />
          )}
          {character && (
            <CharacterDisplay character={character} />
          )}
        </div>
      </main>

      <DebugPanel />
    </div>
  );
}