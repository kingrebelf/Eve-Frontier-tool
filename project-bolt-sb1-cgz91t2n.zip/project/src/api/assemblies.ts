import type { SmartAssembly } from './types';
import { API_CONFIG } from './config';
import { useDebugStore } from '../stores/debugStore';

export async function getAllAssemblies(): Promise<SmartAssembly[]> {
  try {
    const response = await fetch(`${API_CONFIG.baseUrl}/smartassemblies`, {
      method: 'GET',
      headers: {
        'accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    useDebugStore.getState().addResponse({
      timestamp: new Date().toISOString(),
      url: `${API_CONFIG.baseUrl}/smartassemblies`,
      response: data
    });

    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error('Failed to fetch assemblies:', error);
    return [];
  }
}

// Normalize string for comparison
function normalizeString(str: string): string {
  return str.toLowerCase().trim().replace(/\s+/g, ' ');
}

// Filter assemblies by matching owner name with character name
export function filterAssembliesByOwner(
  assemblies: SmartAssembly[], 
  characterName: string
): SmartAssembly[] {
  const normalizedCharacterName = normalizeString(characterName);
  
  return assemblies.filter(assembly => {
    const normalizedOwnerName = normalizeString(assembly.ownerName);
    return normalizedOwnerName === normalizedCharacterName;
  });
}