import { fetchFromAPI } from '../utils/api';
import { endpoints } from './endpoints';
import type { SmartCharacter } from './types';

export async function getCharacters(): Promise<SmartCharacter[]> {
  try {
    const response = await fetchFromAPI<SmartCharacter[]>(
      endpoints.character.list(),
      {
        headers: {
          'Accept': 'application/json'
        }
      }
    );
    return Array.isArray(response) ? response : [];
  } catch (error) {
    console.error('Failed to fetch characters:', error);
    return [];
  }
}