export const API_CONFIG = {
  baseUrl: 'https://blockchain-gateway-stillness.live.tech.evefrontier.com',
  timeout: 10000,
  retries: 2
} as const;