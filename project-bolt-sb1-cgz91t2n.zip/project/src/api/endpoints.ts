export const endpoints = {
  character: {
    list: () => 
      'https://blockchain-gateway-stillness.live.tech.evefrontier.com/smartcharacters',
    search: (query: string) => 
      'https://blockchain-gateway-stillness.live.tech.evefrontier.com/smartcharacters',
    byId: (id: string) => 
      `https://blockchain-gateway-stillness.live.tech.evefrontier.com/smartcharacters/${id}`
  },
  health: (url: string) => `${url}/health`
} as const;