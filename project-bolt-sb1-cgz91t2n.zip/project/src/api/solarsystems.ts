import { fetchFromAPI } from '../utils/api';
import { EVE_CONFIG } from '../config/constants';
import type { SolarSystem, APIResponse } from './types';

export async function fetchSolarSystems(): Promise<SolarSystem[]> {
  const response = await fetchFromAPI<APIResponse<SolarSystem[]>>(
    `${EVE_CONFIG.urls.indexer}/solarsystems`
  );
  return response.data;
}

export async function fetchSolarSystem(id: string): Promise<SolarSystem | null> {
  try {
    const response = await fetchFromAPI<APIResponse<SolarSystem>>(
      `${EVE_CONFIG.urls.indexer}/solarsystems/${id}`
    );
    return response.data;
  } catch (error) {
    if (error.status === 404) return null;
    throw error;
  }
}