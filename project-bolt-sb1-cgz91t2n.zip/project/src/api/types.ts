export interface SmartCharacter {
  address: string;
  id: number;
  name: string;
  image: string;
}

export interface Location {
  x: number;
  y: number;
  z: number;
}

export interface SolarSystem {
  location: Location;
  solarSystemId: number;
  solarSystemName: string;
}

export interface SmartAssembly {
  assemblyType: string;
  chainId: number;
  id: string;
  isOnline: boolean;
  itemId: number;
  name: string;
  ownerId: string;
  ownerName: string;
  solarSystem: SolarSystem;
  state: string;
  stateId: number;
  typeId: number;
}