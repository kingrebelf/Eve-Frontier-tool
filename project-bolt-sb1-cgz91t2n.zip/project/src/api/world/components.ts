import { fetchFromAPI } from '../../utils/api';
import { EVE_CONFIG } from '../../config/constants';
import type { WorldComponent } from './types';

const BASE_URL = `${EVE_CONFIG.urls.base}/world`;

export async function getComponent(id: string): Promise<WorldComponent> {
  return fetchFromAPI(`${BASE_URL}/components/${id}`);
}

export async function getComponentsByOwner(owner: string): Promise<WorldComponent[]> {
  return fetchFromAPI(`${BASE_URL}/components?owner=${owner}`);
}

export async function getComponentsByType(type: string): Promise<WorldComponent[]> {
  return fetchFromAPI(`${BASE_URL}/components?type=${type}`);
}