import { fetchFromAPI } from '../../utils/api';
import { EVE_CONFIG } from '../../config/constants';
import type { WorldSystemCall, WorldTransaction } from './types';

const BASE_URL = `${EVE_CONFIG.urls.base}/world`;

export async function callSystem(params: WorldSystemCall): Promise<WorldTransaction> {
  return fetchFromAPI(`${BASE_URL}/systems/call`, {
    method: 'POST',
    body: JSON.stringify(params)
  });
}

export async function getSystemCallStatus(txHash: string): Promise<WorldTransaction> {
  return fetchFromAPI(`${BASE_URL}/systems/status/${txHash}`);
}