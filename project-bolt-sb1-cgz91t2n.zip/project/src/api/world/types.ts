export interface WorldComponent {
  id: string;
  owner: string;
  componentType: string;
  position: {
    x: number;
    y: number;
    z: number;
  };
  metadata: Record<string, any>;
}

export interface WorldSystemCall {
  systemId: string;
  calldata: string;
  value?: string;
}

export interface WorldTransaction {
  hash: string;
  status: 'pending' | 'confirmed' | 'failed';
  timestamp: string;
}