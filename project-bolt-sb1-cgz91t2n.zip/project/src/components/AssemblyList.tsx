import React from 'react';
import { Power, Box } from 'lucide-react';
import type { SmartAssembly } from '../api/types';

interface AssemblyListProps {
  assemblies: SmartAssembly[];
}

export function AssemblyList({ assemblies }: AssemblyListProps) {
  if (assemblies.length === 0) {
    return (
      <div className="text-center py-8">
        <Box className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <p className="text-gray-500 dark:text-gray-400">
          No assemblies found
        </p>
      </div>
    );
  }

  return (
    <div className="max-h-[400px] overflow-y-auto pr-2 -mr-2">
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        {assemblies.map((assembly) => (
          <div
            key={assembly.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4"
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                  {assembly.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {assembly.assemblyType}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <Power className={`w-4 h-4 ${
                  assembly.isOnline ? 'text-green-500' : 'text-red-500'
                }`} />
                <span className={`text-sm ${
                  assembly.isOnline ? 'text-green-500' : 'text-red-500'
                }`}>
                  {assembly.isOnline ? 'Online' : 'Offline'}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">Owner</span>
                <span className="text-gray-900 dark:text-gray-100">{assembly.ownerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">Solar System</span>
                <span className="text-gray-900 dark:text-gray-100">
                  {assembly.solarSystem.solarSystemName}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">State</span>
                <span className="text-gray-900 dark:text-gray-100">{assembly.state}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}