import React, { useEffect, useState } from 'react';
import { getAllAssemblies, filterAssembliesByOwner } from '../api/assemblies';
import { AssemblyList } from './AssemblyList';
import type { SmartCharacter, SmartAssembly } from '../api/types';

interface CharacterDisplayProps {
  character: SmartCharacter;
}

export function CharacterDisplay({ character }: CharacterDisplayProps) {
  const [assemblies, setAssemblies] = useState<SmartAssembly[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadAssemblies = async () => {
      setIsLoading(true);
      const allAssemblies = await getAllAssemblies();
      const filteredAssemblies = filterAssembliesByOwner(allAssemblies, character.name);
      setAssemblies(filteredAssemblies);
      setIsLoading(false);
    };

    loadAssemblies();
  }, [character.name]);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="flex items-start gap-4">
          <img 
            src={character.image} 
            alt={character.name}
            className="w-24 h-24 rounded-lg object-cover"
          />
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
              {character.name}
            </h2>
            <div className="mt-2 space-y-1">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                ID: {character.id}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 font-mono break-all">
                Address: {character.address}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Smart Assemblies
        </h3>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
          </div>
        ) : (
          <AssemblyList assemblies={assemblies} />
        )}
      </div>
    </div>
  );
}