import React from 'react';
import type { SmartCharacter } from '../api/types';

interface CharacterListProps {
  characters: SmartCharacter[];
  onSelect: (character: SmartCharacter) => void;
}

export function CharacterList({ characters, onSelect }: CharacterListProps) {
  if (characters.length === 0) {
    return (
      <p className="text-gray-500 dark:text-gray-400 text-center py-4">
        No characters found
      </p>
    );
  }

  return (
    <div className="divide-y divide-gray-200 dark:divide-gray-700">
      {characters.map((character) => (
        <button
          key={character.id}
          onClick={() => onSelect(character)}
          className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors rounded-lg"
        >
          <img
            src={character.image}
            alt={character.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="text-left">
            <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">
              {character.name}
            </h4>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              ID: {character.id}
            </p>
          </div>
        </button>
      ))}
    </div>
  );
}