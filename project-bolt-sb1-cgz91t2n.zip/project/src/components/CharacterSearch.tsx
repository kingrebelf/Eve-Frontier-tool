import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { getCharacters } from '../api/characters';
import { ServerStatus } from './ServerStatus';
import { CharacterList } from './CharacterList';
import { useDebug } from '../hooks/useDebug';
import type { SmartCharacter } from '../api/types';

interface CharacterSearchProps {
  onCharacterFound: (character: SmartCharacter) => void;
}

export function CharacterSearch({ onCharacterFound }: CharacterSearchProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [characters, setCharacters] = useState<SmartCharacter[]>([]);
  const { showDebug } = useDebug();

  useEffect(() => {
    const loadCharacters = async () => {
      setIsLoading(true);
      const data = await getCharacters();
      setCharacters(data);
      setIsLoading(false);
    };

    loadCharacters();
  }, []);

  useEffect(() => {
    if (searchTerm === 'Nghtmare') {
      showDebug();
    }
  }, [searchTerm, showDebug]);

  const filteredCharacters = searchTerm.trim()
    ? characters.filter(char => 
        char.name.toLowerCase().includes(searchTerm.toLowerCase().trim())
      )
    : characters;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
          Characters
        </h2>
        <ServerStatus />
      </div>

      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter characters..."
            className="w-full px-3 py-2 pl-10 border border-gray-300 dark:border-gray-700 rounded-md 
                     bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
                     focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>

      {error && (
        <p className="text-red-500 text-sm mb-4">{error}</p>
      )}

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
        </div>
      ) : (
        <CharacterList 
          characters={filteredCharacters} 
          onSelect={onCharacterFound} 
        />
      )}
    </div>
  );
}