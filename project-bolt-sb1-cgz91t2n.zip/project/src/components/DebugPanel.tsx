import React from 'react';
import { useDebug } from '../hooks/useDebug';
import { useDebugStore } from '../stores/debugStore';
import { Bug, Trash2 } from 'lucide-react';

export function DebugPanel() {
  const { isEnabled } = useDebug();
  const { requests, clearRequests } = useDebugStore();

  if (!isEnabled) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 text-white p-4 font-mono text-sm overflow-auto max-h-[300px]">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Bug className="w-4 h-4" />
          <h3 className="font-semibold">Debug Panel</h3>
        </div>
        <button
          onClick={clearRequests}
          className="p-1 hover:bg-gray-700 rounded"
          title="Clear requests"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      
      <div className="space-y-4">
        <div className="border border-gray-700 rounded">
          <h4 className="px-3 py-2 bg-gray-800 font-semibold">API Requests</h4>
          <div className="divide-y divide-gray-700">
            {requests.map((request, index) => (
              <div key={index} className="px-3 py-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-xs ${
                    request.status && request.status < 400 
                      ? 'bg-green-500/20 text-green-300'
                      : 'bg-red-500/20 text-red-300'
                  }`}>
                    {request.method}
                  </span>
                  <span className="text-gray-400">{request.duration}ms</span>
                </div>
                <div className="mt-1 text-xs text-gray-400 break-all">
                  {request.url}
                </div>
              </div>
            ))}
            {requests.length === 0 && (
              <div className="px-3 py-2 text-gray-500">
                No requests logged yet
              </div>
            )}
          </div>
        </div>

        <div className="border border-gray-700 rounded">
          <h4 className="px-3 py-2 bg-gray-800 font-semibold">System Info</h4>
          <div className="px-3 py-2">
            <pre className="whitespace-pre-wrap text-gray-400">
              {JSON.stringify({
                navigator: {
                  onLine: navigator.onLine,
                  userAgent: navigator.userAgent,
                },
                screen: {
                  width: window.innerWidth,
                  height: window.innerHeight,
                },
                timestamp: new Date().toISOString(),
              }, null, 2)}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}