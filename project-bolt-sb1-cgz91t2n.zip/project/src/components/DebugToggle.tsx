import React from 'react';
import { useDebug } from '../hooks/useDebug';
import { Bug } from 'lucide-react';

export function DebugToggle() {
  const { isEnabled, toggle } = useDebug();

  return (
    <button
      onClick={toggle}
      className={`p-2 rounded-lg transition-colors ${
        isEnabled 
          ? 'bg-blue-500 text-white hover:bg-blue-600' 
          : 'bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600'
      }`}
      aria-label="Toggle debug panel"
    >
      <Bug className="w-5 h-5" />
    </button>
  );
}