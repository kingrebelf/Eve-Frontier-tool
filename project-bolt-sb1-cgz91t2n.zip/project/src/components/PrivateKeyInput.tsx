import React, { useState } from 'react';
import { Key } from 'lucide-react';
import { authenticateWithPrivateKey } from '../utils/auth';

interface PrivateKeyInputProps {
  onAuthenticated: (wallet: any) => void;
}

export function PrivateKeyInput({ onAuthenticated }: PrivateKeyInputProps) {
  const [privateKey, setPrivateKey] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const wallet = await authenticateWithPrivateKey(privateKey);
      onAuthenticated(wallet);
    } catch (err) {
      setError('Invalid private key');
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
        Authentication
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <input
            type="password"
            value={privateKey}
            onChange={(e) => setPrivateKey(e.target.value)}
            placeholder="Enter private key"
            className="w-full px-3 py-2 pl-10 border border-gray-300 dark:border-gray-700 rounded-md 
                     bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
                     focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Key className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        <button
          type="submit"
          disabled={!privateKey}
          className="w-full px-4 py-2 bg-blue-500 text-white rounded-md
                   hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500
                   disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Authenticate
        </button>
        {error && (
          <p className="text-red-500 text-sm">{error}</p>
        )}
      </form>
    </div>
  );
}