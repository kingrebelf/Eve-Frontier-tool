import React from 'react';
import { Wifi, WifiOff, ChevronDown, ChevronUp } from 'lucide-react';
import { useServerStatus } from '../hooks/useServerStatus';
import { useState } from 'react';

export function ServerStatus() {
  const { services } = useServerStatus();
  const [isExpanded, setIsExpanded] = useState(false);
  
  const allOnline = services.every(s => s.isOnline);
  const anyOnline = services.some(s => s.isOnline);

  return (
    <div className="relative">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 px-2 py-1 rounded-md transition-colors"
      >
        {anyOnline ? (
          <Wifi className={`w-5 h-5 ${allOnline ? 'text-green-500' : 'text-yellow-500'}`} />
        ) : (
          <WifiOff className="w-5 h-5 text-red-500" />
        )}
        <span className={`text-sm ${
          allOnline ? 'text-green-500' : anyOnline ? 'text-yellow-500' : 'text-red-500'
        }`}>
          {allOnline ? 'All Systems Online' : anyOnline ? 'Partial Outage' : 'Systems Offline'}
        </span>
        {isExpanded ? (
          <ChevronUp className="w-4 h-4" />
        ) : (
          <ChevronDown className="w-4 h-4" />
        )}
      </button>

      {isExpanded && (
        <div className="absolute top-full right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-3 space-y-2 z-50">
          {services.map((service) => (
            <div key={service.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {service.isOnline ? (
                  <Wifi className="w-4 h-4 text-green-500" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-500" />
                )}
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {service.name}
                </span>
              </div>
              {service.isOnline && (
                <span className="text-xs text-gray-500">
                  {service.latency}ms
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}