import React from 'react';
import { List } from 'lucide-react';

export function SmartAssemblyList() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="flex items-center gap-2 mb-4">
        <List className="w-5 h-5 text-blue-500" />
        <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
          Smart Assembly List
        </h2>
      </div>
      <div className="space-y-4">
        {/* Add assembly list items here */}
        <p className="text-gray-600 dark:text-gray-400">
          No items in assembly list yet
        </p>
      </div>
    </div>
  );
}