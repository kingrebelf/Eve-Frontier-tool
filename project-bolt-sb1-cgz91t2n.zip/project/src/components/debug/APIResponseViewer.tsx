import React from 'react';
import { useDebugStore } from '../../stores/debugStore';

export function APIResponseViewer() {
  const { apiResponses } = useDebugStore();
  const assembliesResponse = apiResponses.find(r => 
    r.url.includes('/smartassemblies') && !r.url.includes('?')
  );

  if (!assembliesResponse) {
    return (
      <div className="text-gray-400 text-sm">
        No assemblies response captured yet
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-gray-300">
          Assemblies Response
        </span>
        <span className="text-xs text-gray-400">
          {new Date(assembliesResponse.timestamp).toLocaleTimeString()}
        </span>
      </div>
      <div className="bg-gray-800 rounded p-2 max-h-[200px] overflow-auto">
        <pre className="text-xs text-gray-300 whitespace-pre-wrap">
          {JSON.stringify(assembliesResponse.response, null, 2)}
        </pre>
      </div>
    </div>
  );
}