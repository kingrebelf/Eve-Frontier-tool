import React, { useState } from 'react';
import { useDebug } from '../../hooks/useDebug';
import { useDebugStore } from '../../stores/debugStore';
import { Bug, Trash2, ChevronUp, ChevronDown } from 'lucide-react';
import { APIResponseViewer } from './APIResponseViewer';
import { RequestList } from './RequestList';
import { SystemInfo } from './SystemInfo';

export function DebugPanel() {
  const { isEnabled } = useDebug();
  const { clearRequests, clearResponses } = useDebugStore();
  const [isExpanded, setIsExpanded] = useState(true);

  if (!isEnabled) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 transition-transform duration-200">
      {/* Debug Bar */}
      <div className="bg-gray-800 border-t border-gray-700 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2 text-gray-200">
          <Bug className="w-4 h-4" />
          <span className="font-medium">Debug Tools</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              clearRequests();
              clearResponses();
            }}
            className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-gray-200"
            title="Clear all"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-gray-200"
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronUp className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Debug Content */}
      <div 
        className={`bg-gray-900 text-white overflow-hidden transition-all duration-200 ease-in-out ${
          isExpanded ? 'max-h-[300px]' : 'max-h-0'
        }`}
      >
        <div className="p-4 font-mono text-sm overflow-auto max-h-[300px] border-t border-gray-700">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <RequestList />
              <SystemInfo />
            </div>
            <div className="border border-gray-700 rounded p-3">
              <APIResponseViewer />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}