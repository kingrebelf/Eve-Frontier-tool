import React from 'react';
import { useDebugStore } from '../../stores/debugStore';
import { LayoutList } from 'lucide-react';

export function RequestList() {
  const { requests } = useDebugStore();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <LayoutList className="w-4 h-4" />
        <h4 className="font-medium">API Requests</h4>
      </div>
      <div className="border border-gray-700 rounded divide-y divide-gray-700">
        {requests.map((request, index) => (
          <div key={index} className="px-3 py-2">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded text-xs ${
                request.status && request.status < 400 
                  ? 'bg-green-500/20 text-green-300'
                  : 'bg-red-500/20 text-red-300'
              }`}>
                {request.method}
              </span>
              <span className="text-gray-400">{request.duration}ms</span>
            </div>
            <div className="mt-1 text-xs text-gray-400 break-all">
              {request.url}
            </div>
          </div>
        ))}
        {requests.length === 0 && (
          <div className="px-3 py-2 text-gray-500">
            No requests logged yet
          </div>
        )}
      </div>
    </div>
  );
}