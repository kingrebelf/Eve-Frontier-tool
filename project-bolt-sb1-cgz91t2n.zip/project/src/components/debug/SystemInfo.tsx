import React from 'react';
import { Monitor } from 'lucide-react';

export function SystemInfo() {
  const systemInfo = {
    navigator: {
      onLine: navigator.onLine,
      userAgent: navigator.userAgent,
    },
    screen: {
      width: window.innerWidth,
      height: window.innerHeight,
    },
    timestamp: new Date().toISOString(),
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Monitor className="w-4 h-4" />
        <h4 className="font-medium">System Info</h4>
      </div>
      <div className="border border-gray-700 rounded p-3">
        <pre className="whitespace-pre-wrap text-xs text-gray-400">
          {JSON.stringify(systemInfo, null, 2)}
        </pre>
      </div>
    </div>
  );
}