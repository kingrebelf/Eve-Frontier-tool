export const EVE_CONFIG = {
  chainId: 17069,
  garnetName: 'EVE garnet Game',
  urls: {
    blockExplorer: 'https://explorer.garnetchain.com/',
    metadataApi: 'https://mainnet-game-metadata.nursery.reitnorf.com',
    ipfsApi: 'https://mainnet-game-ipfs-gateway.nursery.reitnorf.com',
    indexer: 'https://graphql-stillness-internal.live.evefrontier.tech/v1/graphql',
    walletApi: 'https://devnet-wallet-api.nursery.reitnorf.com',
    vault: 'https://vault.evefrontier.com',
    base: 'https://smart-assembly-base.stillness.evefrontier.com/',
    rpc: 'https://garnet-rpc.dev.evefrontier.tech'
  },
  contracts: {
    world: '0x7fe660995b0c59b6975d5d59973e2668af6bb9c5',
    eveToken: '0x4b6deF4Ac5Ad63D53BF127e27B6EDe14661B2343',
    forwarder: '0x9CdED8014CAb27154F33349e111e08579CB8B4b7',
    lensSeller: '0x46b0b15d274c494EcB94EB55e4c7Fb73C8BCF634'
  },
  systems: {
    createCharacter: '0x7379657665776f726c64000000000000536d6172744368617261637465725379',
    createAndAnchorSmartStorageUnit: '0x7379657665776f726c64000000000000536d61727453746f72616765556e6974',
    destroyDeployable: '0x7379657665776f726c64000000000000536d6172744465706c6f7961626c6553',
    unanchor: '0x7379657665776f726c64000000000000536d6172744465706c6f7961626c6553',
    bringOnline: '0x7379657665776f726c64000000000000536d6172744465706c6f7961626c6553',
    bringOffline: '0x7379657665776f726c64000000000000536d6172744465706c6f7961626c6553'
  },
  currency: {
    decimals: 18,
    name: 'Gas',
    symbol: 'GAS'
  }
} as const;