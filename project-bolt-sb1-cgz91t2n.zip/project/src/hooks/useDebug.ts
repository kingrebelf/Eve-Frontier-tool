import { useCallback } from 'react';
import { create } from 'zustand';

interface DebugState {
  isEnabled: boolean;
  isVisible: boolean;
  setEnabled: (value: boolean) => void;
  setVisible: (value: boolean) => void;
}

// Initialize with debug enabled by default
const useDebugStore = create<DebugState>((set) => ({
  isEnabled: localStorage.getItem('debug_enabled') !== null 
    ? localStorage.getItem('debug_enabled') === 'true'
    : true, // Default to true if not set
  isVisible: localStorage.getItem('debug_visible') !== null
    ? localStorage.getItem('debug_visible') === 'true'
    : true, // Default to true if not set
  setEnabled: (value) => {
    localStorage.setItem('debug_enabled', String(value));
    set({ isEnabled: value });
  },
  setVisible: (value) => {
    localStorage.setItem('debug_visible', String(value));
    set({ isVisible: value });
  }
}));

export function useDebug() {
  const { isEnabled, isVisible, setEnabled, setVisible } = useDebugStore();

  const toggle = useCallback(() => {
    setEnabled(!isEnabled);
  }, [isEnabled, setEnabled]);

  const showDebug = useCallback(() => {
    setVisible(true);
    setEnabled(true);
  }, [setEnabled, setVisible]);

  return { isEnabled, isVisible, toggle, showDebug };
}