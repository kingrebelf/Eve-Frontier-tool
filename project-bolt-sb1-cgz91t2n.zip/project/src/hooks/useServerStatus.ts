import { useState, useEffect, useCallback } from 'react';
import { API_CONFIG } from '../api/config';

interface ServiceStatus {
  name: string;
  url: string;
  isOnline: boolean;
  latency: number;
}

export function useServerStatus() {
  const [services, setServices] = useState<ServiceStatus[]>([
    { 
      name: 'Blockchain Gateway', 
      url: `${API_CONFIG.baseUrl}/health`, 
      isOnline: false, 
      latency: 0 
    }
  ]);

  const checkStatus = useCallback(async () => {
    const updatedServices = await Promise.all(
      services.map(async (service) => {
        const start = performance.now();
        try {
          const response = await fetch(service.url, {
            headers: {
              'accept': 'application/json'
            }
          });
          const end = performance.now();
          return {
            ...service,
            isOnline: response.ok,
            latency: Math.round(end - start)
          };
        } catch {
          return {
            ...service,
            isOnline: false,
            latency: 0
          };
        }
      })
    );
    setServices(updatedServices);
  }, [services]);

  useEffect(() => {
    checkStatus();
    const interval = setInterval(checkStatus, 30000);
    return () => clearInterval(interval);
  }, [checkStatus]);

  return { services };
}