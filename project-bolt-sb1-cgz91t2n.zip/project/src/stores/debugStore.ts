import { create } from 'zustand';

interface APIRequest {
  timestamp: string;
  method: string;
  url: string;
  status?: number;
  duration: number;
  body?: string;
  error?: string;
}

interface APIResponse {
  timestamp: string;
  url: string;
  response: any;
}

interface DebugStore {
  requests: APIRequest[];
  apiResponses: APIResponse[];
  addRequest: (request: APIRequest) => void;
  addResponse: (response: APIResponse) => void;
  clearRequests: () => void;
  clearResponses: () => void;
}

export const useDebugStore = create<DebugStore>((set) => ({
  requests: [],
  apiResponses: [],
  addRequest: (request) => 
    set((state) => ({
      requests: [request, ...state.requests].slice(0, 10)
    })),
  addResponse: (response) =>
    set((state) => ({
      apiResponses: [response, ...state.apiResponses].slice(0, 5)
    })),
  clearRequests: () => set({ requests: [] }),
  clearResponses: () => set({ apiResponses: [] })
}));