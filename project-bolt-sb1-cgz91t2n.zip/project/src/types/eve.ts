export interface Character {
  id: string;
  name: string;
  assemblies: SmartAssembly[];
}

export interface SmartAssembly {
  id: string;
  name: string;
  status: 'active' | 'inactive';
  contractId?: string;
}