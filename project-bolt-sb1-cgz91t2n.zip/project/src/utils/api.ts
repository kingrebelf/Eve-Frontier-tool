import { API_CONFIG } from '../api/config';
import { useDebugStore } from '../stores/debugStore';

export class APIError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = 'APIError';
  }
}

export async function fetchFromAPI<T>(
  endpoint: string, 
  options: RequestInit = {}
): Promise<T> {
  const startTime = performance.now();
  const method = options.method || 'GET';
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.timeout);

  try {
    const response = await fetch(endpoint, {
      ...options,
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...options.headers,
      },
    });

    clearTimeout(timeoutId);
    const endTime = performance.now();
    
    useDebugStore.getState().addRequest({
      timestamp: new Date().toISOString(),
      method,
      url: endpoint,
      status: response.status,
      duration: Math.round(endTime - startTime),
      body: method !== 'GET' ? options.body : undefined
    });

    if (!response.ok) {
      throw new APIError(
        `Request failed with status ${response.status}`,
        response.status
      );
    }

    const data = await response.json();
    return data as T;
  } catch (error) {
    clearTimeout(timeoutId);
    const endTime = performance.now();

    useDebugStore.getState().addRequest({
      timestamp: new Date().toISOString(),
      method,
      url: endpoint,
      status: error instanceof APIError ? error.status : undefined,
      duration: Math.round(endTime - startTime),
      body: method !== 'GET' ? options.body : undefined,
      error: error.message
    });

    if (error instanceof APIError) {
      throw error;
    }
    if (error.name === 'AbortError') {
      throw new APIError('Request timed out');
    }
    throw new APIError(`Network error: ${error.message}`);
  }
}