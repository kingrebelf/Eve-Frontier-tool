import { ethers } from 'ethers';
import { EVE_CONFIG } from '../config/constants';

export async function authenticateWithPrivateKey(privateKey: string) {
  try {
    const wallet = new ethers.Wallet(privateKey);
    const provider = new ethers.JsonRpcProvider(EVE_CONFIG.urls.rpc);
    return wallet.connect(provider);
  } catch (error) {
    throw new Error('Invalid private key');
  }
}