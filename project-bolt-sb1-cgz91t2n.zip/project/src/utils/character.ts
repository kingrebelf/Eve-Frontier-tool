import { APIError, fetchFromAPI } from './api';
import { endpoints } from '../api/endpoints';
import type { Character } from '../types/eve';

const isValidUUID = (str: string) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
};

export async function findCharacter(searchTerm: string): Promise<Character | null> {
  try {
    const isId = isValidUUID(searchTerm);
    const endpoint = isId
      ? endpoints.character.byId(searchTerm)
      : endpoints.character.search(searchTerm);

    const data = await fetchFromAPI(endpoint);
    
    if (isId) {
      if (!data?.character) return null;
      return mapCharacterData(data.character);
    } else {
      if (!data?.characters?.length) return null;
      return mapCharacterData(data.characters[0]);
    }
  } catch (error) {
    if (error instanceof APIError && error.status === 404) {
      return null;
    }
    throw error;
  }
}

function mapCharacterData(data: any): Character {
  return {
    id: data.id,
    name: data.name,
    assemblies: Array.isArray(data.assemblies) 
      ? data.assemblies.map((assembly: any) => ({
          id: assembly.id,
          name: assembly.name,
          status: assembly.status || 'inactive',
          contractId: assembly.contractId
        }))
      : []
  };
}