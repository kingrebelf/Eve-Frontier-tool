export enum ErrorType {
  CONNECTION = 'CONNECTION',
  AUTHENTICATION = 'AUTHENTICATION',
  NOT_FOUND = 'NOT_FOUND',
  UNKNOWN = 'UNKNOWN'
}

export function getErrorType(error: any): ErrorType {
  if (!navigator.onLine) return ErrorType.CONNECTION;
  
  if (error?.status === 401 || error?.status === 403) {
    return ErrorType.AUTHENTICATION;
  }
  
  if (error?.status === 404) {
    return ErrorType.NOT_FOUND;
  }
  
  if (error?.message?.toLowerCase().includes('network') || 
      error?.message?.toLowerCase().includes('failed to fetch')) {
    return ErrorType.CONNECTION;
  }
  
  return ErrorType.UNKNOWN;
}